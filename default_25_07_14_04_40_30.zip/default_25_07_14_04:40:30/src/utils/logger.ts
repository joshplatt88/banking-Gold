export const logger = {
  info: (message: string, ...args: any[]) => {
    console.info(`[INFO] ${new Date().toISOString()} - ${message}`, ...args);
  },
  warn: (message: string, ...args: any[]) => {
    console.warn(`[WARN] ${new Date().toISOString()} - ${message}`, ...args);
  },
  error: (message: string, ...args: any[]) => {
    console.error(`[ERROR] ${new Date().toISOString()} - ${message}`, ...args);
  },

  auditAdminAction: (action: string, details?: any) => {
    console.info(`[AUDIT] ${new Date().toISOString()} - ADMIN ACTION - ${action}`, details);
  },

  logUserTransactionError: (userId: string, error: string, context?: any) => {
    console.error(
      `[TRANSACTION ERROR] ${new Date().toISOString()} - User ${userId} - Error: ${error}`,
      context,
    );
  },
};
