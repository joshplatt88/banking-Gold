import { logger } from './logger';

export function handleError(error: any, contextMessage: string = '') {
  let errorMessage = 'An unexpected error occurred.';
  if (error?.message) errorMessage = error.message;
  else if (typeof error === 'string') errorMessage = error;

  logger.error(`${contextMessage} - ${errorMessage}`, error);
  // You could extend this to show user notifications or send errors to monitoring services here.
  return errorMessage;
}
