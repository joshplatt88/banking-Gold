import * as yup from 'yup';

export const adminWithdrawSchema = yup.object().shape({
  amount: yup
    .number()
    .required('Amount is required')
    .positive('Amount must be greater than zero')
    .typeError('Amount must be a number'),
});

export const loanApprovalSchema = yup.object().shape({
  decision: yup.string().oneOf(['approve', 'reject']).required(),
  adminNote: yup.string().optional(),
});

export const chequingAccountOpenSchema = yup.object().shape({
  agreeTos: yup.boolean().oneOf([true], 'You must agree to terms').required(),
});

export const transactionFilterSchema = yup.object().shape({
  dateFrom: yup.date().nullable(),
  dateTo: yup.date().nullable(),
  transactionType: yup.string().oneOf(['deposit', 'withdrawal', 'loan_repayment', 'fee_charge', 'bet', 'reward_redemption', 'all']),
  amountMin: yup.number().nullable().positive(),
  amountMax: yup
    .number()
    .nullable()
    .moreThan(yup.ref('amountMin'), 'Max amount must be greater than min amount'),
});
