export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user' | 'guest';
  isAuthenticated: boolean;

  chequingAccountId?: string;
  transactionLogIds?: string[];
}
