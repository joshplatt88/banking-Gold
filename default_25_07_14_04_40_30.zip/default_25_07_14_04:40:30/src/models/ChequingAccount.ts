export interface ChequingAccount {
  id: string;
  userId: string;
  accountNumber: string;
  balance: number;
  linkedPaymentMethods: string[]; // e.g. payment method IDs
  openedAt: string; // ISO string
  transactions: string[]; // transaction log IDs pertaining to this account
}
