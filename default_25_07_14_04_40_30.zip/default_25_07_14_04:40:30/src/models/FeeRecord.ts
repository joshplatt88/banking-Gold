export interface FeeRecord {
  id: string;
  source: 'loan_interest' | 'holding_fee' | 'penalty' | 'ai_subscription' | 'bets' | 'other';
  amount: number;
  timestamp: string; // ISO string
  withdrawn: boolean;
}
