export interface TransactionLog {
  id: string;
  userId: string;
  transactionType:
    | 'deposit'
    | 'withdrawal'
    | 'loan_repayment'
    | 'fee_charge'
    | 'bet'
    | 'reward_redemption'
    | 'balance_preference_change';
  amount: number;
  timestamp: string; // ISO string
  resultantBalance: number;
  status: 'pending' | 'success' | 'failed';
  comment?: string;
}
