export interface LoanApplication {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  creditScore?: number;
  collateralValue?: number;
  status: 'pending' | 'approved' | 'rejected';
  adminNotes?: string;
  createdAt: string; // ISO string
  updatedAt: string; // ISO string
}
