import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import AdminDashboard from '../screens/Admin/AdminDashboard';
import WalletDashboard from '../screens/Wallet/WalletDashboard';
import TransactionLogsScreen from '../screens/Logs/TransactionLogsScreen';
import { RootState } from '../store';
import { Ionicons } from '@expo/vector-icons';

const Tab = createBottomTabNavigator();

const Navigation = () => {
  const user = useSelector((state: RootState) => state.user.user);

  return (
    <NavigationContainer>
      <Tab.Navigator
        initialRouteName="Wallet"
        screenOptions={({ route }) => ({
          tabBarActiveTintColor: '#d4af37',
          tabBarInactiveTintColor: '#bbb',
          tabBarStyle: {
            backgroundColor: '#0c2340',
            borderTopColor: '#0c2340',
            height: 60,
            paddingBottom: 6,
            paddingTop: 6,
          },
          headerStyle: {
            backgroundColor: '#0c2340',
          },
          headerTintColor: '#d4af37',
          tabBarIcon: ({ focused, color, size }) => {
            let iconName = 'home-outline';

            if (route.name === 'Admin' && user?.role === 'admin') {
              iconName = focused ? 'settings' : 'settings-outline';
            } else if (route.name === 'Logs') {
              iconName = focused ? 'document-text' : 'document-text-outline';
            } else if (route.name === 'Wallet') {
              iconName = focused ? 'wallet' : 'wallet-outline';
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
        })}
      >
        <Tab.Screen
          name="Wallet"
          component={WalletDashboard}
          options={{ title: 'Wallet' }}
        />
        {user?.isAuthenticated && (
          <Tab.Screen
            name="Logs"
            component={TransactionLogsScreen}
            options={{ title: 'Logs' }}
          />
        )}
        {user?.role === 'admin' && (
          <Tab.Screen
            name="Admin"
            component={AdminDashboard}
            options={{ title: 'Admin' }}
          />
        )}
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default Navigation;
