import React, { useEffect, useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../store';
import { fetchTransactionLogsAsync } from '../../store/logSlice';
import DateRangePicker from '../../components/DateRangePicker';
import { format } from 'date-fns';

const transactionTypes = [
  'all',
  'deposit',
  'withdrawal',
  'loan_repayment',
  'fee_charge',
  'bet',
  'reward_redemption',
];

const TransactionLogsScreen = () => {
  const dispatch = useDispatch();
  const { logs, loading, error } = useSelector((state: RootState) => state.logs);

  const [filterType, setFilterType] = useState<string>('all');
  const [filterStartDate, setFilterStartDate] = useState<Date | null>(null);
  const [filterEndDate, setFilterEndDate] = useState<Date | null>(null);
  const [filterMinAmount, setFilterMinAmount] = useState<string>('');
  const [filterMaxAmount, setFilterMaxAmount] = useState<string>('');
  const [page, setPage] = useState<number>(1);

  useEffect(() => {
    dispatch(fetchTransactionLogsAsync({ page }));
  }, [dispatch, page]);

  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      if (filterType !== 'all' && log.transactionType !== filterType) return false;
      const logDate = new Date(log.timestamp);
      if (filterStartDate && logDate < filterStartDate) return false;
      if (filterEndDate && logDate > filterEndDate) return false;
      const minAmt = parseFloat(filterMinAmount);
      if (filterMinAmount && (!log.amount || log.amount < minAmt)) return false;
      const maxAmt = parseFloat(filterMaxAmount);
      if (filterMaxAmount && (!log.amount || log.amount > maxAmt)) return false;
      return true;
    });
  }, [logs, filterType, filterStartDate, filterEndDate, filterMinAmount, filterMaxAmount]);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Transaction Logs</Text>
      <View style={styles.filtersContainer}>
        <DateRangePicker
          startDate={filterStartDate}
          endDate={filterEndDate}
          onChangeStartDate={setFilterStartDate}
          onChangeEndDate={setFilterEndDate}
          style={styles.datePicker}
        />
        <View style={styles.row}>
          <View style={styles.filterColumn}>
            <Text style={styles.filterLabel}>Transaction Type</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {transactionTypes.map((type) => (
                <TouchableOpacity
                  key={type}
                  style={[
                    styles.typeButton,
                    filterType === type && styles.typeButtonActive,
                  ]}
                  onPress={() => setFilterType(type)}
                >
                  <Text
                    style={[
                      styles.typeButtonText,
                      filterType === type && styles.typeButtonTextActive,
                    ]}
                  >
                    {type.charAt(0).toUpperCase() + type.slice(1).replace('_', ' ')}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
        <View style={styles.row}>
          <View style={styles.filterColumn}>
            <Text style={styles.filterLabel}>Min Amount</Text>
            <TextInput
              style={styles.input}
              keyboardType="numeric"
              placeholder="Any"
              placeholderTextColor="#888"
              value={filterMinAmount}
              onChangeText={setFilterMinAmount}
            />
          </View>
          <View style={styles.filterColumn}>
            <Text style={styles.filterLabel}>Max Amount</Text>
            <TextInput
              style={styles.input}
              keyboardType="numeric"
              placeholder="Any"
              placeholderTextColor="#888"
              value={filterMaxAmount}
              onChangeText={setFilterMaxAmount}
            />
          </View>
        </View>
      </View>
      {loading ? (
        <ActivityIndicator color="#d4af37" size="large" />
      ) : error ? (
        <Text style={styles.errorText}>{error}</Text>
      ) : (
        <FlatList
          data={filteredLogs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())}
          keyExtractor={(item) => item.id}
          style={styles.list}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 32 }}
          ListEmptyComponent={() => (
            <View style={styles.noDataContainer}>
              <Text style={styles.noDataText}>No transactions found.</Text>
            </View>
          )}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <View style={styles.cardRow}>
                <Text style={styles.cardTitle}>{item.transactionType.replace('_', ' ').toUpperCase()}</Text>
                <Text style={styles.cardAmount}>
                  {item.amount ? `$${item.amount.toFixed(2)}` : '-'}
                </Text>
              </View>
              <Text style={styles.cardBody}>{item.comment || '-'}</Text>
              <View style={styles.cardRow}>
                <Text style={styles.cardTimestamp}>
                  {format(new Date(item.timestamp), 'MMM d, yyyy HH:mm')}
                </Text>
                <Text style={[styles.cardStatus, item.status === 'success' ? styles.success : styles.failure]}>
                  {item.status.toUpperCase()}
                </Text>
              </View>
              <Text style={styles.cardBalance}>
                Balance After: ${item.resultantBalance?.toFixed(2) ?? '-'}
              </Text>
            </View>
          )}
          onEndReached={() => setPage((p) => p + 1)}
          onEndReachedThreshold={0.5}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#0c2340',
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  header: {
    color: '#d4af37',
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 12,
    fontFamily: 'System',
  },
  filtersContainer: {
    marginBottom: 24,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  filterColumn: {
    flex: 1,
    marginRight: 12,
  },
  filterLabel: {
    color: '#d4af37',
    marginBottom: 6,
    fontWeight: '600',
  },
  input: {
    backgroundColor: '#142a5c',
    borderColor: '#d4af37',
    borderWidth: 1,
    borderRadius: 8,
    color: '#fff',
    paddingHorizontal: 12,
    height: 44,
    fontWeight: '600',
  },
  list: {
    flex: 1,
  },
  card: {
    backgroundColor: '#142a5c',
    borderRadius: 10,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 4,
    elevation: 2,
  },
  cardRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  cardTitle: {
    color: '#d4af37',
    fontWeight: '700',
    fontSize: 16,
  },
  cardAmount: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
  },
  cardBody: {
    color: '#bbb',
    fontSize: 14,
    marginBottom: 8,
    fontStyle: 'italic',
  },
  cardTimestamp: {
    color: '#bbb',
    fontSize: 12,
  },
  cardStatus: {
    fontWeight: '700',
    fontSize: 12,
    textTransform: 'uppercase',
  },
  success: {
    color: '#66cc66',
  },
  failure: {
    color: '#e25555',
  },
  cardBalance: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 13,
    marginTop: 6,
    fontStyle: 'normal',
  },
  noDataContainer: {
    paddingVertical: 40,
  },
  noDataText: {
    color: '#bbb',
    fontStyle: 'italic',
    fontSize: 16,
    textAlign: 'center',
  },
  datePicker: {
    marginBottom: 16,
  },
  typeButton: {
    backgroundColor: '#214175',
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginRight: 8,
    borderRadius: 20,
  },
  typeButtonActive: {
    backgroundColor: '#d4af37',
  },
  typeButtonText: {
    color: '#d4af37',
    fontWeight: '600',
  },
  typeButtonTextActive: {
    color: '#0c2340',
  },
});

export default TransactionLogsScreen;
