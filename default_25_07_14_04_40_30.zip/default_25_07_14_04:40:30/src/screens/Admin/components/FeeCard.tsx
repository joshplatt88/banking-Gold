import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { FeeRecord } from '../../../models/FeeRecord';
import { format } from 'date-fns';

type FeeCardProps = {
  fee: FeeRecord;
};

const sourceDisplayNames: Record<string, string> = {
  loan_interest: 'Loan Interest',
  holding_fee: 'Holding Fee',
  penalty: 'Liquidation Penalty',
  ai_subscription: 'AI Subscription',
  bets: 'Bet Fees',
  other: 'Other',
};

const FeeCard: React.FC<FeeCardProps> = ({ fee }) => {
  return (
    <View style={styles.card}>
      <View style={styles.row}>
        <Text style={styles.source}>{sourceDisplayNames[fee.source] || fee.source}</Text>
        <Text style={styles.amount}>${fee.amount.toFixed(2)}</Text>
      </View>
      <View style={styles.row}>
        <Text style={styles.timestamp}>{format(new Date(fee.timestamp), 'MMM d, yyyy HH:mm')}</Text>
        <Text style={[styles.status, fee.withdrawn ? styles.withdrawn : styles.pending]}>
          {fee.withdrawn ? 'Withdrawn' : 'Pending'}
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#142a5c',
    borderRadius: 10,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 4,
    elevation: 2,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  source: {
    color: '#d4af37',
    fontWeight: '700',
    fontSize: 16,
  },
  amount: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
  },
  timestamp: {
    color: '#bbb',
    fontSize: 12,
    marginTop: 6,
  },
  status: {
    color: '#bbb',
    fontWeight: '600',
    fontSize: 12,
    marginTop: 6,
  },
  withdrawn: {
    color: '#66cc66',
  },
  pending: {
    color: '#f4a261',
  },
});

export default FeeCard;
