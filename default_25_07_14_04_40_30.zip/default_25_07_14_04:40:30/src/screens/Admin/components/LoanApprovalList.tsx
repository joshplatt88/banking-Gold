import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  ScrollView,
} from 'react-native';
import { LoanApplication } from '../../../models/LoanApplication';

type Props = {
  loanApplications: LoanApplication[];
  onApprove: (loanId: string) => void;
  onReject: (loanId: string) => void;
};

type SortKey = 'user' | 'amount' | 'creditScore' | 'collateral';
type SortOrder = 'asc' | 'desc';

const LoanApprovalList: React.FC<Props> = ({ loanApplications, onApprove, onReject }) => {
  const [sortKey, setSortKey] = useState<SortKey>('user');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');

  const sortedLoans = useMemo(() => {
    const sorted = [...loanApplications];
    sorted.sort((a, b) => {
      let aValue: string | number = '';
      let bValue: string | number = '';

      switch (sortKey) {
        case 'user':
          aValue = a.userName.toLowerCase();
          bValue = b.userName.toLowerCase();
          break;
        case 'amount':
          aValue = a.amount;
          bValue = b.amount;
          break;
        case 'creditScore':
          aValue = a.creditScore || 0;
          bValue = b.creditScore || 0;
          break;
        case 'collateral':
          aValue = a.collateralValue || 0;
          bValue = b.collateralValue || 0;
          break;
      }

      if (aValue < bValue) return sortOrder === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
    return sorted;
  }, [loanApplications, sortKey, sortOrder]);

  const toggleSort = (key: SortKey) => {
    if (key === sortKey) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortOrder('asc');
    }
  };

  const confirmApprove = (id: string) => {
    Alert.alert(
      'Approve Loan',
      'Are you sure you want to approve this loan application?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Approve', onPress: () => onApprove(id), style: 'default' },
      ],
    );
  };

  const confirmReject = (id: string) => {
    Alert.alert(
      'Reject Loan',
      'Are you sure you want to reject this loan application?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Reject', onPress: () => onReject(id), style: 'destructive' },
      ],
    );
  };

  if (loanApplications.length === 0) {
    return (
      <View style={styles.noDataContainer}>
        <Text style={styles.noDataText}>No pending loan applications.</Text>
      </View>
    );
  }

  return (
    <ScrollView style={{ marginTop: 6 }}>
      <View style={styles.tableHeader}>
        <TouchableOpacity onPress={() => toggleSort('user')} style={[styles.cell, styles.flex2]}>
          <Text style={styles.headerText}>User {sortKey === 'user' ? (sortOrder === 'asc' ? '▲' : '▼') : ''}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => toggleSort('amount')} style={styles.cell}>
          <Text style={styles.headerText}>Amount {sortKey === 'amount' ? (sortOrder === 'asc' ? '▲' : '▼') : ''}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => toggleSort('creditScore')} style={styles.cell}>
          <Text style={styles.headerText}>Credit Score {sortKey === 'creditScore' ? (sortOrder === 'asc' ? '▲' : '▼') : ''}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => toggleSort('collateral')} style={styles.cell}>
          <Text style={styles.headerText}>Collateral {sortKey === 'collateral' ? (sortOrder === 'asc' ? '▲' : '▼') : ''}</Text>
        </TouchableOpacity>
        <View style={[styles.cell, styles.actionsCell]}>
          <Text style={styles.headerText}>Actions</Text>
        </View>
      </View>
      {sortedLoans.map((loan, index) => (
        <View
          key={loan.id}
          style={[
            styles.tableRow,
            index % 2 === 0 ? styles.rowLight : styles.rowDark,
          ]}
        >
          <Text style={[styles.cell, styles.flex2, styles.cellText]}>{loan.userName}</Text>
          <Text style={[styles.cell, styles.cellText]}>${loan.amount.toFixed(2)}</Text>
          <Text style={[styles.cell, styles.cellText]}>{loan.creditScore ?? '-'}</Text>
          <Text style={[styles.cell, styles.cellText]}>
            ${loan.collateralValue ? loan.collateralValue.toFixed(2) : '-'}
          </Text>
          <View style={[styles.cell, styles.actionsCell, styles.actionsRow]}>
            <TouchableOpacity
              style={[styles.actionBtn, styles.approveBtn]}
              onPress={() => confirmApprove(loan.id)}
            >
              <Text style={styles.actionText}>Approve</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionBtn, styles.rejectBtn]}
              onPress={() => confirmReject(loan.id)}
            >
              <Text style={styles.actionText}>Reject</Text>
            </TouchableOpacity>
          </View>
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#214175',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 12,
    paddingHorizontal: 12,
    alignItems: 'center',
  },
  rowLight: {
    backgroundColor: '#142a5c',
  },
  rowDark: {
    backgroundColor: '#0c2340',
  },
  cell: {
    flex: 1,
    paddingHorizontal: 6,
  },
  flex2: {
    flex: 2,
  },
  headerText: {
    color: '#d4af37',
    fontWeight: '700',
    fontSize: 14,
  },
  cellText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  actionsCell: {
    flex: 2,
  },
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    gap: 12,
  },
  actionBtn: {
    borderRadius: 6,
    paddingVertical: 6,
    paddingHorizontal: 14,
    marginRight: 12,
  },
  approveBtn: {
    backgroundColor: '#66cc66',
  },
  rejectBtn: {
    backgroundColor: '#e25555',
  },
  actionText: {
    color: '#0c2340',
    fontWeight: '700',
    fontSize: 14,
    textAlign: 'center',
  },
  noDataContainer: {
    marginTop: 16,
    paddingVertical: 40,
  },
  noDataText: {
    color: '#bbb',
    fontStyle: 'italic',
    fontSize: 16,
    textAlign: 'center',
  },
});

export default LoanApprovalList;
