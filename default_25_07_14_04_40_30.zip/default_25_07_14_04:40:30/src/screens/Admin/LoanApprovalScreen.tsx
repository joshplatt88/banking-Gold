import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../store';
import {
  fetchLoanApplicationsAsync,
  approveLoanAsync,
  rejectLoanAsync,
} from '../../store/adminSlice';
import { LoanApplication } from '../../models/LoanApplication';

const LoanApprovalScreen = () => {
  const dispatch = useDispatch();
  const { loans, loadingLoans } = useSelector((state: RootState) => state.admin);
  const [selectedLoan, setSelectedLoan] = useState<LoanApplication | null>(null);

  useEffect(() => {
    dispatch(fetchLoanApplicationsAsync());
  }, [dispatch]);

  const handleApprove = (id: string) => {
    Alert.alert(
      'Approve Loan',
      'Are you sure you want to approve this loan?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Approve',
          onPress: () => dispatch(approveLoanAsync(id)),
          style: 'default',
        },
      ],
    );
  };

  const handleReject = (id: string) => {
    Alert.alert(
      'Reject Loan',
      'Are you sure you want to reject this loan?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reject',
          onPress: () => dispatch(rejectLoanAsync(id)),
          style: 'destructive',
        },
      ],
    );
  };

  const renderLoan = ({ item }: { item: LoanApplication }) => (
    <View style={styles.loanRow}>
      <Text style={[styles.loanCell, styles.cellUser]}>{item.userName}</Text>
      <Text style={styles.loanCell}>${item.amount.toFixed(2)}</Text>
      <Text style={styles.loanCell}>{item.creditScore ?? '-'}</Text>
      <Text style={styles.loanCell}>
        ${item.collateralValue ? item.collateralValue.toFixed(2) : '-'}
      </Text>
      <View style={[styles.loanCell, styles.cellActions]}>
        <TouchableOpacity
          style={[styles.actionBtn, styles.approveBtn]}
          onPress={() => handleApprove(item.id)}
        >
          <Text style={styles.actionText}>Approve</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.actionBtn, styles.rejectBtn]}
          onPress={() => handleReject(item.id)}
        >
          <Text style={styles.actionText}>Reject</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Pending Loan Applications</Text>
      {loadingLoans ? (
        <ActivityIndicator color="#d4af37" size="large" />
      ) : loans.pending.length === 0 ? (
        <View style={styles.noData}>
          <Text style={styles.noDataText}>No pending loan applications.</Text>
        </View>
      ) : (
        <>
          <View style={styles.loanHeader}>
            <Text style={[styles.loanCell, styles.cellUser]}>User</Text>
            <Text style={styles.loanCell}>Amount</Text>
            <Text style={styles.loanCell}>Credit Score</Text>
            <Text style={styles.loanCell}>Collateral</Text>
            <Text style={[styles.loanCell, styles.cellActions]}>Actions</Text>
          </View>
          <FlatList
            data={loans.pending}
            keyExtractor={(item) => item.id}
            renderItem={renderLoan}
            style={styles.loanList}
            contentContainerStyle={{ paddingBottom: 30 }}
          />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#0c2340',
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  header: {
    color: '#d4af37',
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 16,
  },
  loanHeader: {
    flexDirection: 'row',
    backgroundColor: '#214175',
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: 10,
  },
  loanList: {
    marginTop: 6,
  },
  loanRow: {
    flexDirection: 'row',
    paddingVertical: 14,
    paddingHorizontal: 10,
    backgroundColor: '#142a5c',
    borderRadius: 10,
    marginBottom: 12,
    alignItems: 'center',
  },
  loanCell: {
    flex: 1,
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  cellUser: {
    flex: 2,
    fontWeight: '700',
    color: '#d4af37',
  },
  cellActions: {
    flex: 2,
    flexDirection: 'row',
    gap: 12,
  },
  actionBtn: {
    borderRadius: 6,
    paddingVertical: 6,
    paddingHorizontal: 14,
  },
  approveBtn: {
    backgroundColor: '#66cc66',
  },
  rejectBtn: {
    backgroundColor: '#e25555',
  },
  actionText: {
    color: '#0c2340',
    fontWeight: '700',
    fontSize: 14,
    textAlign: 'center',
  },
  noData: {
    marginTop: 40,
    paddingVertical: 40,
  },
  noDataText: {
    color: '#bbb',
    fontStyle: 'italic',
    fontSize: 16,
    textAlign: 'center',
  },
});

export default LoanApprovalScreen;
