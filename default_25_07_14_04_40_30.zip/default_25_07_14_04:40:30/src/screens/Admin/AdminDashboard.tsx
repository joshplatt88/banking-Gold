import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Modal,
  Alert,
  TextInput,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../store';
import {
  fetchFeesAsync,
  withdrawFeesAsync,
  fetchLoanApplicationsAsync,
  approveLoanAsync,
  rejectLoanAsync,
} from '../../store/adminSlice';
import FeeCard from './components/FeeCard';
import LoanApprovalList from './components/LoanApprovalList';
import { format } from 'date-fns';
import DateRangePicker from '../../components/DateRangePicker';
import { Ionicons } from '@expo/vector-icons';

const AdminDashboard = () => {
  const dispatch = useDispatch();
  const {
    fees,
    loans,
    loadingFees,
    loadingLoans,
    withdrawing,
    withdrawingError,
    withdrawingSuccess,
  } = useSelector((state: RootState) => state.admin);

  const [filterStartDate, setFilterStartDate] = useState<Date | null>(null);
  const [filterEndDate, setFilterEndDate] = useState<Date | null>(null);
  const [withdrawModalVisible, setWithdrawModalVisible] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawError, setWithdrawError] = useState('');

  useEffect(() => {
    dispatch(fetchFeesAsync());
    dispatch(fetchLoanApplicationsAsync());
  }, [dispatch]);

  const onWithdrawPress = () => {
    setWithdrawError('');
    const numAmount = parseFloat(withdrawAmount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setWithdrawError('Please enter a valid positive amount');
      return;
    }
    if (numAmount > fees.totalAmount) {
      setWithdrawError('Amount exceeds total fees');
      return;
    }

    Alert.alert(
      'Confirm Withdrawal',
      `Are you sure you want to withdraw $${numAmount.toFixed(2)} in fees?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Confirm',
          onPress: () => {
            dispatch(withdrawFeesAsync(numAmount));
            setWithdrawModalVisible(false);
            setWithdrawAmount('');
          },
          style: 'destructive',
        },
      ],
    );
  };

  // Filter fees by date - if filter null, show all
  const filteredFees = fees.feeRecords.filter((fee) => {
    const feeDate = new Date(fee.timestamp);
    if (filterStartDate && feeDate < filterStartDate) return false;
    if (filterEndDate && feeDate > filterEndDate) return false;
    return true;
  });

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 32 }}>
      <Text style={styles.header}>Platform Fees Overview</Text>
      <DateRangePicker
        startDate={filterStartDate}
        endDate={filterEndDate}
        onChangeStartDate={setFilterStartDate}
        onChangeEndDate={setFilterEndDate}
        style={styles.datePicker}
      />
      {loadingFees ? (
        <ActivityIndicator color="#d4af37" size="large" style={{ marginTop: 20 }} />
      ) : (
        <>
          <View style={styles.feesList}>
            {filteredFees.length === 0 ? (
              <Text style={styles.noDataText}>No fee data for selected dates.</Text>
            ) : (
              filteredFees.map((fee) => (
                <FeeCard key={fee.id} fee={fee} />
              ))
            )}
          </View>
          <View style={styles.summaryCard}>
            <Text style={styles.summaryTitle}>Total Fees Collected</Text>
            <Text style={styles.summaryAmount}>${fees.totalAmount.toFixed(2)}</Text>
            <TouchableOpacity
              style={styles.withdrawButton}
              onPress={() => setWithdrawModalVisible(true)}
              disabled={fees.totalAmount <= 0 || withdrawing}
            >
              {withdrawing ? (
                <ActivityIndicator color="#0c2340" />
              ) : (
                <Text style={styles.withdrawButtonText}>Withdraw Fees</Text>
              )}
            </TouchableOpacity>
            {withdrawingError && (
              <Text style={styles.errorText}>{withdrawingError}</Text>
            )}
            {withdrawingSuccess && (
              <Text style={styles.successText}>Withdrawal successful</Text>
            )}
          </View>
        </>
      )}
      <Text style={[styles.header, { marginTop: 32 }]}>Loan Approvals</Text>
      {loadingLoans ? (
        <ActivityIndicator color="#d4af37" size="large" style={{ marginTop: 20 }} />
      ) : (
        <LoanApprovalList
          loanApplications={loans.pending}
          onApprove={(id) => dispatch(approveLoanAsync(id))}
          onReject={(id) => dispatch(rejectLoanAsync(id))}
        />
      )}

      <Modal
        animationType="slide"
        transparent
        visible={withdrawModalVisible}
        onRequestClose={() => setWithdrawModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>Withdraw Fees</Text>
            <Text style={styles.modalLabel}>Amount to withdraw</Text>
            <View style={styles.inputContainer}>
              <TextInput
                keyboardType="numeric"
                value={withdrawAmount}
                onChangeText={setWithdrawAmount}
                style={styles.modalInput}
                placeholder="Enter amount"
                placeholderTextColor="#999"
              />
            </View>
            {withdrawError ? <Text style={styles.errorText}>{withdrawError}</Text> : null}
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: '#ccc' }]}
                onPress={() => setWithdrawModalVisible(false)}
              >
                <Text style={[styles.modalButtonText, { color: '#333' }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: '#d4af37' }]}
                onPress={onWithdrawPress}
              >
                <Text style={[styles.modalButtonText, { color: '#0c2340' }]}>Withdraw</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#0c2340',
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  header: {
    color: '#d4af37',
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 12,
    fontFamily: 'System',
  },
  datePicker: {
    marginBottom: 16,
  },
  feesList: {
    marginBottom: 20,
  },
  noDataText: {
    color: '#bbb',
    fontSize: 16,
    fontStyle: 'italic',
    textAlign: 'center',
    marginVertical: 20,
  },
  summaryCard: {
    backgroundColor: '#142a5c',
    borderRadius: 10,
    padding: 20,
    marginBottom: 30,
    shadowColor: '#d4af37',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.4,
    shadowRadius: 5,
    elevation: 5,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 6,
  },
  summaryAmount: {
    fontSize: 32,
    fontWeight: '700',
    color: '#d4af37',
    marginBottom: 20,
  },
  withdrawButton: {
    backgroundColor: '#d4af37',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  withdrawButtonText: {
    color: '#0c2340',
    fontWeight: '700',
    fontSize: 16,
  },
  errorText: {
    marginTop: 12,
    color: '#e25555',
    fontWeight: '600',
    fontSize: 14,
  },
  successText: {
    marginTop: 12,
    color: '#66cc66',
    fontWeight: '600',
    fontSize: 14,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(12, 35, 64, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  modalContainer: {
    backgroundColor: '#142a5c',
    borderRadius: 12,
    width: '100%',
    maxWidth: 400,
    padding: 24,
    shadowColor: '#d4af37',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.6,
    shadowRadius: 15,
    elevation: 10,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#d4af37',
    marginBottom: 20,
  },
  modalLabel: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
    marginBottom: 8,
  },
  inputContainer: {
    backgroundColor: '#0c2340',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#d4af37',
    marginBottom: 10,
  },
  modalInput: {
    color: '#fff',
    paddingHorizontal: 14,
    fontSize: 16,
    height: 44,
    fontWeight: '600',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  modalButton: {
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  modalButtonText: {
    fontWeight: '700',
    fontSize: 16,
    textAlign: 'center',
  },
});

export default AdminDashboard;
