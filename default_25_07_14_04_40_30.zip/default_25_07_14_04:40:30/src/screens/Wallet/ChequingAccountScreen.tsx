import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../store';
import {
  openChequingAccountAsync,
  depositToChequingAsync,
  withdrawFromChequingAsync,
  fetchChequingAccountAsync,
} from '../../store/chequingSlice';

const presetAmounts = [100, 250, 500, 1000];

const ChequingAccountScreen = () => {
  const dispatch = useDispatch();
  const { account, loading, error } = useSelector(
    (state: RootState) => state.chequing,
  );

  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');

  useEffect(() => {
    dispatch(fetchChequingAccountAsync());
  }, [dispatch]);

  const canOpenAccount = !account;

  const onOpenAccount = () => {
    Alert.alert(
      'Open Chequing Account',
      'Do you want to open a new Chequing Account?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Open',
          onPress: () => dispatch(openChequingAccountAsync()),
          style: 'default',
        },
      ],
    );
  };

  const onDeposit = (amount: number) => {
    dispatch(depositToChequingAsync(amount));
    setDepositAmount('');
  };

  const onWithdraw = (amount: number) => {
    if (account && amount > account.balance) {
      Alert.alert(
        'Insufficient Funds',
        'You do not have enough balance to withdraw that amount.',
      );
      return;
    }
    dispatch(withdrawFromChequingAsync(amount));
    setWithdrawAmount('');
  };

  const parsedDepositAmount = parseFloat(depositAmount);
  const parsedWithdrawAmount = parseFloat(withdrawAmount);

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      <Text style={styles.header}>Chequing Account</Text>

      {loading && <ActivityIndicator size="large" color="#d4af37" style={{ marginTop: 20 }} />}
      {error && <Text style={styles.errorText}>{error}</Text>}

      {!account && !loading ? (
        <View style={styles.openAccountContainer}>
          <Text style={styles.infoText}>
            You do not have a chequing account yet. Opening one is simple and free.
          </Text>
          <TouchableOpacity style={styles.openAccountButton} onPress={onOpenAccount}>
            <Text style={styles.openAccountButtonText}>Open Chequing Account</Text>
          </TouchableOpacity>
        </View>
      ) : null}

      {account && (
        <>
          <View style={styles.balanceCard}>
            <Text style={styles.label}>Account Number</Text>
            <Text style={styles.accountNumber}>{account.accountNumber}</Text>
            <Text style={styles.label}>Balance</Text>
            <Text style={styles.balance}>${account.balance.toFixed(2)}</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionHeader}>Deposit Money</Text>
            <View style={styles.presetRow}>
              {presetAmounts.map((amt) => (
                <TouchableOpacity
                  key={amt}
                  style={styles.presetButton}
                  onPress={() => onDeposit(amt)}
                >
                  <Text style={styles.presetButtonText}>Deposit ${amt}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TextInput
              placeholder="Custom amount"
              placeholderTextColor="#888"
              keyboardType="numeric"
              style={styles.input}
              value={depositAmount}
              onChangeText={setDepositAmount}
            />
            <TouchableOpacity
              style={[
                styles.actionButton,
                { backgroundColor: parsedDepositAmount > 0 ? '#d4af37' : '#777' },
              ]}
              disabled={!(parsedDepositAmount > 0)}
              onPress={() => onDeposit(parsedDepositAmount)}
            >
              <Text style={styles.actionButtonText}>Deposit</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionHeader}>Withdraw Money</Text>
            <View style={styles.presetRow}>
              <TouchableOpacity
                style={styles.presetButton}
                onPress={() => account && onWithdraw(account.balance)}
              >
                <Text style={styles.presetButtonText}>Withdraw Max</Text>
              </TouchableOpacity>
              {presetAmounts.map((amt) => (
                <TouchableOpacity
                  key={amt}
                  style={styles.presetButton}
                  onPress={() => onWithdraw(amt)}
                >
                  <Text style={styles.presetButtonText}>Withdraw ${amt}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TextInput
              placeholder="Custom amount"
              placeholderTextColor="#888"
              keyboardType="numeric"
              style={styles.input}
              value={withdrawAmount}
              onChangeText={setWithdrawAmount}
            />
            <TouchableOpacity
              style={[
                styles.actionButton,
                { backgroundColor: parsedWithdrawAmount > 0 ? '#d4af37' : '#777' },
              ]}
              disabled={!(parsedWithdrawAmount > 0)}
              onPress={() => onWithdraw(parsedWithdrawAmount)}
            >
              <Text style={styles.actionButtonText}>Withdraw</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#0c2340',
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  header: {
    fontSize: 26,
    fontWeight: '700',
    color: '#d4af37',
    marginBottom: 24,
    fontFamily: 'System',
  },
  openAccountContainer: {
    backgroundColor: '#142a5c',
    borderRadius: 10,
    padding: 20,
    alignItems: 'center',
  },
  infoText: {
    color: '#bbb',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 20,
    textAlign: 'center',
  },
  openAccountButton: {
    backgroundColor: '#d4af37',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 10,
  },
  openAccountButtonText: {
    color: '#0c2340',
    fontWeight: '700',
    fontSize: 18,
  },
  balanceCard: {
    backgroundColor: '#142a5c',
    borderRadius: 12,
    padding: 20,
    marginBottom: 30,
    shadowColor: '#d4af37',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 6,
  },
  label: {
    color: '#d4af37',
    fontWeight: '600',
    fontSize: 16,
    marginBottom: 6,
  },
  accountNumber: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 22,
    marginBottom: 16,
  },
  balance: {
    color: '#d4af37',
    fontWeight: '700',
    fontSize: 26,
  },
  section: {
    marginBottom: 40,
  },
  sectionHeader: {
    color: '#d4af37',
    fontWeight: '700',
    fontSize: 20,
    marginBottom: 16,
  },
  presetRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 12,
    gap: 12,
  },
  presetButton: {
    backgroundColor: '#214175',
    minWidth: 100,
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 14,
    marginRight: 12,
    marginBottom: 12,
  },
  presetButtonText: {
    color: '#d4af37',
    fontWeight: '700',
    fontSize: 15,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#142a5c',
    borderRadius: 10,
    borderColor: '#d4af37',
    borderWidth: 1,
    height: 44,
    paddingHorizontal: 16,
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
    marginBottom: 10,
  },
  actionButton: {
    backgroundColor: '#d4af37',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#0c2340',
    fontWeight: '700',
    fontSize: 18,
  },
  errorText: {
    marginTop: 12,
    color: '#e25555',
    fontWeight: '600',
    fontSize: 14,
    textAlign: 'center',
  },
});

export default ChequingAccountScreen;
