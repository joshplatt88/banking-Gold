import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';

const WalletDashboard = () => {
  const navigation = useNavigation();
  const { balances, feeSummary, yieldReceived } = useSelector(
    (state: RootState) => state.wallet,
  );
  const chequingAccount = useSelector(
    (state: RootState) => state.chequing.account,
  );

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      <Text style={styles.header}>My Wallet</Text>
      <View style={styles.cardsContainer}>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Stable-value Wallet</Text>
          <Text style={styles.cardAmount}>${balances.stableValue.toFixed(2)}</Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Market-value Wallet</Text>
          <Text style={styles.cardAmount}>${balances.marketValue.toFixed(2)}</Text>
        </View>
        <View style={styles.card}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={styles.cardTitle}>Chequing Account</Text>
            {!chequingAccount && (
              <TouchableOpacity onPress={() => navigation.navigate('ChequingAccount' as never)}>
                <Text style={styles.openAccountLink}>Open Now</Text>
              </TouchableOpacity>
            )}
          </View>
          <Text style={styles.cardAmount}>
            ${chequingAccount ? chequingAccount.balance.toFixed(2) : '0.00'}
          </Text>
          {chequingAccount && (
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => navigation.navigate('ChequingAccount' as never)}
            >
              <Text style={styles.actionButtonText}>Manage Account</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
      <View style={styles.feeYieldContainer}>
        <View style={styles.feeYieldCard}>
          <Text style={styles.summaryTitle}>Fees Applied</Text>
          <Text style={styles.summaryAmount}>${feeSummary.feesApplied.toFixed(2)}</Text>
        </View>
        <View style={styles.feeYieldCard}>
          <Text style={styles.summaryTitle}>Yield Received</Text>
          <Text style={styles.summaryAmount}>${yieldReceived.toFixed(2)}</Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#0c2340',
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  header: {
    fontSize: 26,
    fontWeight: '700',
    color: '#d4af37',
    marginBottom: 20,
    fontFamily: 'System',
  },
  cardsContainer: {
    flexDirection: 'column',
    gap: 16,
    marginBottom: 40,
  },
  card: {
    backgroundColor: '#142a5c',
    borderRadius: 12,
    padding: 24,
    marginBottom: 16,
    shadowColor: '#d4af37',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 7,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#d4af37',
    marginBottom: 8,
  },
  cardAmount: {
    fontSize: 28,
    fontWeight: '700',
    color: '#fff',
  },
  openAccountLink: {
    color: '#d4af37',
    fontWeight: '700',
    textDecorationLine: 'underline',
    fontSize: 14,
  },
  actionButton: {
    marginTop: 20,
    backgroundColor: '#d4af37',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#0c2340',
    fontWeight: '700',
    fontSize: 16,
  },
  feeYieldContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 16,
  },
  feeYieldCard: {
    flex: 1,
    backgroundColor: '#142a5c',
    borderRadius: 12,
    padding: 20,
    shadowColor: '#d4af37',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
    elevation: 6,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#d4af37',
    marginBottom: 8,
  },
  summaryAmount: {
    fontSize: 24,
    fontWeight: '700',
    color: '#fff',
  },
});

export default WalletDashboard;
