import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { format } from 'date-fns';

type Props = {
  startDate: Date | null;
  endDate: Date | null;
  onChangeStartDate: (date: Date | null) => void;
  onChangeEndDate: (date: Date | null) => void;
  style?: any;
};

const DateRangePicker: React.FC<Props> = ({
  startDate,
  endDate,
  onChangeStartDate,
  onChangeEndDate,
  style,
}) => {
  // Because complex date pickers require native support or libs,
  // we'll implement a simple tap-to-clear functionality here.
  // User taps start or end date to clear date.

  return (
    <View style={[styles.container, style]}>
      <TouchableOpacity onPress={() => onChangeStartDate(null)} style={styles.dateBox}>
        <Text style={styles.label}>From</Text>
        <Text style={styles.dateText}>
          {startDate ? format(startDate, 'MMM d, yyyy') : 'Any'}
        </Text>
      </TouchableOpacity>
      <Text style={styles.toText}>–</Text>
      <TouchableOpacity onPress={() => onChangeEndDate(null)} style={styles.dateBox}>
        <Text style={styles.label}>To</Text>
        <Text style={styles.dateText}>
          {endDate ? format(endDate, 'MMM d, yyyy') : 'Any'}
        </Text>
      </TouchableOpacity>
      <Text style={styles.helpText}>(Tap dates to clear filter)</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  dateBox: {
    backgroundColor: '#142a5c',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 8,
    minWidth: 110,
    alignItems: 'center',
  },
  label: {
    fontSize: 12,
    color: '#d4af37',
    fontWeight: '600',
  },
  dateText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    marginTop: 2,
  },
  toText: {
    fontSize: 24,
    fontWeight: '700',
    color: '#d4af37',
    marginHorizontal: 12,
  },
  helpText: {
    fontSize: 10,
    color: '#bbb',
    marginLeft: 10,
    fontStyle: 'italic',
  },
});

export default DateRangePicker;
