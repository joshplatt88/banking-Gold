import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import api from '../services/api';
import { TransactionLog } from '../models/TransactionLog';

interface LogsState {
  logs: TransactionLog[];
  loading: boolean;
  error: string | null;
  page: number;
  pageSize: number;
  noMore: boolean;
}

const initialState: LogsState = {
  logs: [],
  loading: false,
  error: null,
  page: 1,
  pageSize: 25,
  noMore: false,
};

export const fetchTransactionLogsAsync = createAsyncThunk(
  'logs/fetchLogs',
  async (
    params: { page?: number; filters?: Record<string, any> } = {},
    { getState, rejectWithValue },
  ) => {
    try {
      const state = getState() as { logs: LogsState };
      const page = params.page ?? state.logs.page;
      const pageSize = state.logs.pageSize;
      const data = await api.fetchTransactionLogs({
        page,
        pageSize,
        filters: params.filters,
      });
      return { data, page };
    } catch (err) {
      return rejectWithValue('Failed to fetch transaction logs.');
    }
  },
);

const logSlice = createSlice({
  name: 'logs',
  initialState,
  reducers: {
    resetLogs(state) {
      state.logs = [];
      state.page = 1;
      state.noMore = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTransactionLogsAsync.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTransactionLogsAsync.fulfilled, (state, action: PayloadAction<{ data: TransactionLog[]; page: number }>) => {
        state.loading = false;
        if (action.payload.page === 1) {
          state.logs = action.payload.data;
        } else {
          state.logs = [...state.logs, ...action.payload.data];
        }
        state.page = action.payload.page;
        if (action.payload.data.length < state.pageSize) {
          state.noMore = true;
        }
      })
      .addCase(fetchTransactionLogsAsync.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { resetLogs } = logSlice.actions;
export default logSlice.reducer;
