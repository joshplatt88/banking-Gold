import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import api from '../services/api';
import { FeeRecord } from '../models/FeeRecord';
import { LoanApplication } from '../models/LoanApplication';

type FeesState = {
  feeRecords: FeeRecord[];
  totalAmount: number;
};

interface AdminState {
  fees: FeesState;
  loans: {
    pending: LoanApplication[];
  };
  loadingFees: boolean;
  loadingLoans: boolean;
  withdrawing: boolean;
  withdrawingError: string | null;
  withdrawingSuccess: boolean;
}

const initialState: AdminState = {
  fees: {
    feeRecords: [],
    totalAmount: 0,
  },
  loans: {
    pending: [],
  },
  loadingFees: false,
  loadingLoans: false,
  withdrawing: false,
  withdrawingError: null,
  withdrawingSuccess: false,
};

export const fetchFeesAsync = createAsyncThunk('admin/fetchFees', async () => {
  const data = await api.fetchFees();
  return data;
});

export const withdrawFeesAsync = createAsyncThunk(
  'admin/withdrawFees',
  async (amount: number, { rejectWithValue }) => {
    try {
      const data = await api.withdrawFees(amount);
      return data;
    } catch (err) {
      return rejectWithValue('Withdrawal failed.');
    }
  },
);

export const fetchLoanApplicationsAsync = createAsyncThunk('admin/fetchLoans', async () => {
  const data = await api.fetchLoanApplications();
  return data;
});

export const approveLoanAsync = createAsyncThunk(
  'admin/approveLoan',
  async (loanId: string, { rejectWithValue }) => {
    try {
      const data = await api.approveLoan(loanId);
      return { loanId, data };
    } catch (err) {
      return rejectWithValue('Approve loan failed.');
    }
  },
);

export const rejectLoanAsync = createAsyncThunk(
  'admin/rejectLoan',
  async (loanId: string, { rejectWithValue }) => {
    try {
      const data = await api.rejectLoan(loanId);
      return { loanId, data };
    } catch (err) {
      return rejectWithValue('Reject loan failed.');
    }
  },
);

const adminSlice = createSlice({
  name: 'admin',
  initialState,
  reducers: {
    resetWithdrawStatus: (state) => {
      state.withdrawingError = null;
      state.withdrawingSuccess = false;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchFeesAsync.pending, (state) => {
        state.loadingFees = true;
      })
      .addCase(fetchFeesAsync.fulfilled, (state, action: PayloadAction<FeesState>) => {
        state.fees = action.payload;
        state.loadingFees = false;
      })
      .addCase(fetchFeesAsync.rejected, (state) => {
        state.loadingFees = false;
      })
      .addCase(withdrawFeesAsync.pending, (state) => {
        state.withdrawing = true;
        state.withdrawingError = null;
        state.withdrawingSuccess = false;
      })
      .addCase(withdrawFeesAsync.fulfilled, (state, action) => {
        state.withdrawing = false;
        state.withdrawingSuccess = true;
        state.fees = {
          ...state.fees,
          totalAmount: Math.max(state.fees.totalAmount - action.meta.arg, 0),
          feeRecords: state.fees.feeRecords.map((fee) =>
            !fee.withdrawn && fee.amount <= action.meta.arg ? { ...fee, withdrawn: true } : fee,
          ),
        };
      })
      .addCase(withdrawFeesAsync.rejected, (state, action) => {
        state.withdrawing = false;
        state.withdrawingError = action.payload as string;
      })
      .addCase(fetchLoanApplicationsAsync.pending, (state) => {
        state.loadingLoans = true;
      })
      .addCase(fetchLoanApplicationsAsync.fulfilled, (state, action) => {
        state.loans.pending = action.payload;
        state.loadingLoans = false;
      })
      .addCase(fetchLoanApplicationsAsync.rejected, (state) => {
        state.loadingLoans = false;
      })
      .addCase(approveLoanAsync.fulfilled, (state, action) => {
        state.loans.pending = state.loans.pending.filter((loan) => loan.id !== action.payload.loanId);
      })
      .addCase(rejectLoanAsync.fulfilled, (state, action) => {
        state.loans.pending = state.loans.pending.filter((loan) => loan.id !== action.payload.loanId);
      });
  },
});

export const { resetWithdrawStatus } = adminSlice.actions;

export default adminSlice.reducer;
