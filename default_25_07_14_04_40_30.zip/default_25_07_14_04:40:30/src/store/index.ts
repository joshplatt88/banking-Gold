import { configureStore } from '@reduxjs/toolkit';
import userReducer from './userSlice';
import walletReducer from './walletSlice';
import loanReducer from './loanSlice';
import paymentReducer from './paymentSlice';
import adminReducer from './adminSlice';
import logReducer from './logSlice';
import chequingReducer from './chequingSlice';

export const store = configureStore({
  reducer: {
    user: userReducer,
    wallet: walletReducer,
    loan: loanReducer,
    payment: paymentReducer,
    admin: adminReducer,
    logs: logReducer,
    chequing: chequingReducer,
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware({ serializableCheck: false }),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
