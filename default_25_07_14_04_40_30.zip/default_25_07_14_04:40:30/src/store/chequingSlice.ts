import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import api from '../services/api';
import { ChequingAccount } from '../models/ChequingAccount';

interface ChequingState {
  account: ChequingAccount | null;
  loading: boolean;
  error: string | null;
}

const initialState: ChequingState = {
  account: null,
  loading: false,
  error: null,
};

export const fetchChequingAccountAsync = createAsyncThunk('chequing/fetchAccount', async (_, { rejectWithValue }) => {
  try {
    const data = await api.fetchChequingAccount();
    return data;
  } catch {
    return rejectWithValue('Failed to fetch chequing account.');
  }
});

export const openChequingAccountAsync = createAsyncThunk('chequing/openAccount', async (_, { rejectWithValue }) => {
  try {
    const data = await api.openChequingAccount();
    return data;
  } catch {
    return rejectWithValue('Failed to open chequing account.');
  }
});

export const depositToChequingAsync = createAsyncThunk('chequing/deposit', async (amount: number, { rejectWithValue }) => {
  try {
    const data = await api.depositToChequing(amount);
    return data;
  } catch {
    return rejectWithValue('Failed to deposit to chequing account.');
  }
});

export const withdrawFromChequingAsync = createAsyncThunk('chequing/withdraw', async (amount: number, { rejectWithValue }) => {
  try {
    const data = await api.withdrawFromChequing(amount);
    return data;
  } catch {
    return rejectWithValue('Failed to withdraw from chequing account.');
  }
});

const chequingSlice = createSlice({
  name: 'chequing',
  initialState,
  reducers: {
    resetError(state) {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchChequingAccountAsync.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchChequingAccountAsync.fulfilled, (state, action: PayloadAction<ChequingAccount>) => {
        state.account = action.payload;
        state.loading = false;
      })
      .addCase(fetchChequingAccountAsync.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(openChequingAccountAsync.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(openChequingAccountAsync.fulfilled, (state, action: PayloadAction<ChequingAccount>) => {
        state.account = action.payload;
        state.loading = false;
      })
      .addCase(openChequingAccountAsync.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(depositToChequingAsync.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(depositToChequingAsync.fulfilled, (state, action: PayloadAction<ChequingAccount>) => {
        state.account = action.payload;
        state.loading = false;
      })
      .addCase(depositToChequingAsync.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(withdrawFromChequingAsync.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(withdrawFromChequingAsync.fulfilled, (state, action: PayloadAction<ChequingAccount>) => {
        state.account = action.payload;
        state.loading = false;
      })
      .addCase(withdrawFromChequingAsync.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { resetError } = chequingSlice.actions;

export default chequingSlice.reducer;
