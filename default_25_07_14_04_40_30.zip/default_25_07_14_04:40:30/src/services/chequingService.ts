import api from './api';
import { ChequingAccount } from '../models/ChequingAccount';

export const chequingService = {
  async fetchChequingAccount(): Promise<ChequingAccount> {
    return await api.fetchChequingAccount();
  },

  async openChequingAccount(): Promise<ChequingAccount> {
    return await api.openChequingAccount();
  },

  async deposit(amount: number): Promise<ChequingAccount> {
    return await api.depositToChequing(amount);
  },

  async withdraw(amount: number): Promise<ChequingAccount> {
    return await api.withdrawFromChequing(amount);
  },
};
