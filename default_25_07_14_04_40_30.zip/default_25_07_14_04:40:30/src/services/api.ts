import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'https://api.example.com';

const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 12000,
  headers: {
    'Content-Type': 'application/json',
  },
});

export default {
  // Admin - Fees
  fetchFees: async (): Promise<any> => {
    const response = await axiosInstance.get('/admin/fees');
    return response.data;
  },

  withdrawFees: async (amount: number): Promise<any> => {
    const response = await axiosInstance.post('/admin/fees/withdraw', { amount });
    return response.data;
  },

  // Admin - Loans
  fetchLoanApplications: async (): Promise<any> => {
    const response = await axiosInstance.get('/admin/loans?status=pending');
    return response.data;
  },

  approveLoan: async (loanId: string): Promise<any> => {
    const response = await axiosInstance.post(`/admin/loans/${loanId}/approve`);
    return response.data;
  },

  rejectLoan: async (loanId: string): Promise<any> => {
    const response = await axiosInstance.post(`/admin/loans/${loanId}/reject`);
    return response.data;
  },

  // User - Transaction Logs
  fetchTransactionLogs: async (params: {
    page?: number;
    pageSize?: number;
    filters?: Record<string, any>;
  }): Promise<any> => {
    const response = await axiosInstance.get('/user/transactions', { params });
    return response.data;
  },

  // Chequing Account
  fetchChequingAccount: async (): Promise<any> => {
    const response = await axiosInstance.get('/user/chequing');
    return response.data;
  },

  openChequingAccount: async (): Promise<any> => {
    const response = await axiosInstance.post('/user/chequing/open');
    return response.data;
  },

  depositToChequing: async (amount: number): Promise<any> => {
    const response = await axiosInstance.post('/user/chequing/deposit', { amount });
    return response.data;
  },

  withdrawFromChequing: async (amount: number): Promise<any> => {
    const response = await axiosInstance.post('/user/chequing/withdraw', { amount });
    return response.data;
  },
};
