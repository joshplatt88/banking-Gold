import api from './api';
import { FeeRecord } from '../models/FeeRecord';
import { LoanApplication } from '../models/LoanApplication';

export const adminService = {
  async getFees(): Promise<{ feeRecords: FeeRecord[]; totalAmount: number }> {
    return await api.fetchFees();
  },

  async withdrawFees(amount: number): Promise<void> {
    await api.withdrawFees(amount);
  },

  async getPendingLoanApplications(): Promise<LoanApplication[]> {
    return await api.fetchLoanApplications();
  },

  async approveLoan(loanId: string): Promise<void> {
    await api.approveLoan(loanId);
  },

  async rejectLoan(loanId: string): Promise<void> {
    await api.rejectLoan(loanId);
  },
};
