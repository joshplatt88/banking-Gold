import api from './api';
import { TransactionLog } from '../models/TransactionLog';

interface FetchParams {
  page?: number;
  pageSize?: number;
  filters?: Record<string, any>;
}

export const logService = {
  async getUserTransactionLogs(params: FetchParams): Promise<TransactionLog[]> {
    return await api.fetchTransactionLogs(params);
  },
};
