# BankingGold React Native App

This React Native application implements a polished crypto banking experience with extended features including an Admin tab, user Transaction Logs, and a Chequing Account system. The UI is designed to closely match the aesthetic of [BankingGold Studio](https://studio--bankinggold.us-central1.hosted.app/), featuring navy blue and gold accent themes, spacious layouts, clear typography, and smooth animations.

---

## Features

- **Admin Tab** (visible only to admin users):  
  - View detailed platform fee reports aggregated by fee source with filters by date range.  
  - Withdraw collected platform fees with multi-step confirmation.  
  - Manage pending loan applications with sortable lists, approve/reject functionality, and audit logging.

- **Logs Tab** (visible to authenticated users):  
  - Access full, paginated transaction histories covering deposits, withdrawals, loan repayments, fees, bets, and rewards.  
  - Filter transactions by type, date ranges, and amount.

- **Chequing Account Feature**:  
  - Open a new chequing account with a single tap.  
  - Deposit or withdraw instantly using preset amounts or custom amounts.  
  - Real-time balance updates and transaction receipts.  
  - Easy management within the Wallet screen.

- **Consistent UI/UX**:  
  - Dark navy backgrounds with gold highlights.  
  - Card-based design for clear separation of content areas.  
  - Intuitive navigation adapted for mobile from the reference site.  
  - Inline validation and helpful user feedback.

---

## Requirements

- Node.js LTS (>= 16.x)
- Yarn or npm
- React Native CLI environment set up for iOS and/or Android

---

## Installation & Setup

1. Clone the repository:

   